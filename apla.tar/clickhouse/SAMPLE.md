http://сигачев.рф/posts/82

Clickhouse Yandex log analyzer. Создаем анализатор логов на базе Clickhouse. Clickhouse vs mysql. Делаем систему аналитики

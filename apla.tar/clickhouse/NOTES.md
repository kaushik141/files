# Notes

## Testing on node 10.x

Seems like memwatch-next is not supported anymore,
so replace it with @airbnb/node-memwatch. Airbnb's version
not supports node < 8 (https://github.com/andywer/leakage/pull/27)
